<?php
include("config.php");
if (!loggedin()) {
    header("Location: login.php");
    exit();
} if ($_SESSION['user_role'] != 'admin') {
    header("Location: index.php");
    exit();
}
?>

<?php
// error_reporting(0);

include 'models/Report.php';
$reportObj = new Report();

if (isset($_POST['report_update'])) {

    $id = $_POST['id_update'];
    $comment = mysqli_real_escape_string($con, trim($_POST['comment']));

    $errors = array();

    if (empty($comment)) {
        $errors[] = "Please enter all fields!";
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            //echo $error, '<br />';
            echo get_error($error);
        }
    } else {

        $reportObj->update([
            'id'        => $id,
            'comment'   => $comment,
        ]);

        echo get_success(trans('updatedSuccessfully'));
    }
}
?>
<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<?php include("include/leftsidebar.php"); ?>
<div class="wrapper">
    <div class="container">    <!-- Start content -->
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title"> <?php echo trans('Reports'); ?> </h4>
                <ol class="breadcrumb">
                    <li>
                        <a href=""><?php echo trans('Reports'); ?>  </a>
                    </li>
                    <li class="active">
                        <?php echo trans('editReport'); ?>
                    </li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card-box">
                    <?php
                    if (isset($_GET['report_id'])) {
                        $row_select = $reportObj->getById($_GET['report_id']);

                        $id = $row_select['id'];
                        $comment = $row_select['comment'];

                        if ($row_select) {
                            ?>

                            <form method="POST" data-parsley-validate novalidate>

                                <input type="hidden" name="id_update" id="id_update" parsley-trigger="change"  value="<?php echo $id; ?>" class="form-control">


                                <div class="form-group">
                                    <label for="comment"><?php echo trans('comment'); ?>  </label>
                                    <input  value="<?php echo $comment; ?>" id="comment" name="comment" required class="form-control">
                                </div>

                                <div class="clearfix"></div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="text-center p-20">
                                            <button type="reset" class="btn w-sm btn-white waves-effect"><?php echo trans('cancel'); ?></button>
                                            <button type="submit" name="report_update" class="btn w-sm btn-default waves-effect waves-light"><?php echo trans('update'); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>



</div>
</div>
<?php include("include/footer_text.php"); ?>

<?php include("include/footer.php"); ?>

<script>
    // $(document).ready(function(){
    $("#navigation ul>li").removeClass("active");
    $("#item2").addClass("active");
    // })
</script>

</body>
</html>