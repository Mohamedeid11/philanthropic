<?php
include("config.php");
if (!loggedin()) {
    header("Location: login.php");
    exit();
} if ($_SESSION['user_role'] != 'admin') {
    header("Location: index.php");
    exit();
}
?>

<?php
// error_reporting(0);

include 'models/Review.php';
$reviewObj = new Review();

if (isset($_POST['review_update'])) {

    $id = $_POST['id_update'];
    $rate = mysqli_real_escape_string($con, trim($_POST['rate']));
    $comment = mysqli_real_escape_string($con, trim($_POST['comment']));

    $errors = array();

    if (empty($comment)) {
        $errors[] = "Please enter all fields!";
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            //echo $error, '<br />';
            echo get_error($error);
        }
    } else {

        $reviewObj->update([
            'id'        => $id,
            'rate'      => $rate,
            'comment'   => $comment,
        ]);

        echo get_success(trans('updatedSuccessfully'));
    }
}
?>
<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<?php include("include/leftsidebar.php"); ?>
<div class="wrapper">
    <div class="container">    <!-- Start content -->
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title"> <?php echo trans('reviews'); ?> </h4>
                <ol class="breadcrumb">
                    <li>
                        <a href=""><?php echo trans('reviews'); ?>  </a>
                    </li>
                    <li class="active">
                        <?php echo trans('editReview'); ?>
                    </li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card-box">
                    <?php
                    if (isset($_GET['review_id'])) {
                        $row_select = $reviewObj->getById($_GET['review_id']);

                        $id = $row_select['id'];
                        $rate = $row_select['rate'];
                        $comment = $row_select['comment'];

                        if ($row_select) {
                            ?>

                            <form method="POST" data-parsley-validate novalidate>

                                <input type="hidden" name="id_update" id="id_update" parsley-trigger="change"  value="<?php echo $id; ?>" class="form-control">

                                <div class="form-group col-md-3">
                                    <label for="rate"><?php echo trans('rate'); ?></label>
                                    <select id="rate" name="rate" required class="form-control">
                                        <option <?= $rate == 1 ? 'selected' : '' ?> value="1">1</option>
                                        <option <?= $rate == 2 ? 'selected' : '' ?> value="2">2</option>
                                        <option <?= $rate == 3 ? 'selected' : '' ?> value="3">3</option>
                                        <option <?= $rate == 4 ? 'selected' : '' ?> value="4">4</option>
                                        <option <?= $rate == 5 ? 'selected' : '' ?> value="5">5</option>
                                    </select>
                                </div>

                                <div class="form-group col-md-9">
                                    <label for="comment"><?php echo trans('comment'); ?>  </label>
                                    <input  value="<?php echo $comment; ?>" id="comment" name="comment" required class="form-control">
                                </div>

                                <div class="clearfix"></div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="text-center p-20">
                                            <button type="reset" class="btn w-sm btn-white waves-effect"><?php echo trans('cancel'); ?></button>
                                            <button type="submit" name="review_update" class="btn w-sm btn-default waves-effect waves-light"><?php echo trans('update'); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>



</div>
</div>
<?php include("include/footer_text.php"); ?>

<?php include("include/footer.php"); ?>

<script>
    // $(document).ready(function(){
    $("#navigation ul>li").removeClass("active");
    $("#item2").addClass("active");
    // })
</script>

</body>
</html>