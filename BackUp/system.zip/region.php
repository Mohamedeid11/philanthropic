<?php

include "models/Model.php";
include "models/Region.php";
$regionObj = new Region();
if($_POST['type'] == 'delete') {
    $regionObj->delete($_POST['id']);
}