<?php
include("config.php");
if (!loggedin()) {
    header("Location: login.php");
    exit();
} if ($_SESSION['user_role'] != 'admin') {
    header("Location: index.php");
    exit();
}

include 'models/User.php';
$userObj = new User();

if (isset($_POST['submit'])) {

    $user_id = mysqli_real_escape_string($con, trim($_POST['user_id']));
    $name_ar = mysqli_real_escape_string($con, trim($_POST['name_ar']));
    $name_en = mysqli_real_escape_string($con, trim($_POST['name_en']));
    $desc_ar = !empty($_POST['desc_ar']) ? $_POST['desc_ar'] : null;
    $desc_en = !empty($_POST['desc_en']) ? $_POST['desc_en'] : null;
    $condition_rules_ar = !empty($_POST['condition_rules_ar']) ? $_POST['condition_rules_ar'] : null;
    $condition_rules_en = !empty($_POST['condition_rules_en']) ? $_POST['condition_rules_en'] : null;
    $check_availability = isset($_POST['check_availability']) && $_POST['check_availability'] == 'on' ? 1 : 0;
    $code = !empty($_POST['code']) ? $_POST['code'] : null;
    $price = mysqli_real_escape_string($con, trim($_POST['price']));
    $price_weekend = !empty($_POST['price_weekend']) ? $_POST['price_weekend'] : null;;
    $discount = $_POST['discountType'] == 1 ? $_POST['discount'] : 0;
    $weekendDiscount = $_POST['weekendDiscountType'] == 1 ? $_POST['weekendDiscount'] : 0;
    $address_ar = !empty($_POST['address_ar']) ? $_POST['address_ar'] : null;
    $address_en = !empty($_POST['address_en']) ? $_POST['address_en'] : null;
    $lat = mysqli_real_escape_string($con, trim($_POST['lat']));
    $long = mysqli_real_escape_string($con, trim($_POST['long']));
    $space = !empty($_POST['space']) ? $_POST['space'] : null;
    $mobile = !empty($_POST['mobile']) ? $_POST['mobile'] : null;
    $whatsapp = !empty($_POST['whatsapp']) ? $_POST['whatsapp'] : null;
    $region_id = !empty($_POST['region']) ? $_POST['region'] : 0;
    $payment_ar = $_POST['payment_ar'];
    $payment_en = $_POST['payment_en'];
    $size_ar = $_POST['size_ar'];
    $size_en = $_POST['size_en'];
    $period_ar = $_POST['period_ar'];
    $period_en = $_POST['period_en'];
    $ball       = isset($_POST['ball']) && $_POST['ball'] == 'on' ? 1 : 0;
    $numbers    = isset($_POST['numbers']) && $_POST['numbers'] == 'on' ? 1 : 0;
    $covered    = isset($_POST['covered']) && $_POST['covered'] == 'on' ? 1 : 0;
    $shower     = isset($_POST['shower']) && $_POST['shower'] == 'on' ? 1 : 0;
    $water      = isset($_POST['water']) && $_POST['water'] == 'on' ? 1 : 0;
    $paidWater  = isset($_POST['paidWater']) && $_POST['paidWater'] == 'on' && $water == 1 ? 1 : 0;
    $wc         = isset($_POST['wc']) && $_POST['wc'] == 'on' ? 1 : 0;

    $image_name = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];

    $video_name = $_FILES['video']['name'];
    $video_tmp = $_FILES['video']['tmp_name'];

    $errors = array();

    if (empty($name_ar) || empty($name_en) || empty($price)) {
        $errors[] = trans('namePriceRequired');
    } elseif (!is_numeric($price)) {
        $errors[] = trans('priceNumeric');
    } elseif (!is_null($price_weekend) && !is_numeric($price_weekend)) {
        $errors[] = trans('priceWeekendNumeric');
    } elseif (!is_numeric($discount)) {
        $errors[] = trans('discountNumeric');
    } elseif (!is_numeric($weekendDiscount)) {
        $errors[] = trans('discountNumeric');
    } elseif (!is_numeric($lat) || !is_numeric($long)) {
        $errors[] = trans('locationNumeric');
    } elseif (!empty($mobile) && !is_numeric($mobile)) {
        $errors[] = trans('mobileNumeric');
    } elseif (!empty($whatsapp) && !is_numeric($whatsapp)) {
        $errors[] = trans('mobileNumeric');
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo get_error($error);
        }
    } else {
        include 'models/Entity.php';
        $entityObj = new Entity();
        $id = $entityObj->create([
            'type' => 4,
            'family' => 0,
            'user_id' => $user_id,
            'name_ar' => $name_ar,
            'name_en' => $name_en,
            'desc_ar' => $desc_ar,
            'desc_en' => $desc_en,
            'condition_rules_ar' => $condition_rules_ar,
            'condition_rules_en' => $condition_rules_en,
            'check_availability' => $check_availability,
            'code' => $code,
            'price' => $price,
            'price_weekend' => $price_weekend,
            'discount' => $discount,
            'weekend_discount' => $weekendDiscount,
            'address_ar' => $address_ar,
            'address_en' => $address_en,
            'lat_loca' => $lat,
            'long_loca' => $long,
            'space' => $space,
            'mobile' => $mobile,
            'whatsapp' => $whatsapp,
            'views' => 0,
            'region_id' => $region_id,
            'capacitance' => null,
            'pool' => null,
            'amenities' => null,
            'kitchenAmenities' => null,
            'bedroom' => null,
            'countBedrooms' => null,
            'display' => 1,
            'date' => date('Y-m-d H:i:s'),
        ]);

        if ($id) {

            include 'models/Feature.php';
            $featureObj = new Feature();
            if ($ball == 1) {
                $featureObj->create([
                    'type' => 'ball',
                    'entity_id' => $id,
                    'name_ar' => 1,
                    'name_en' => 1,
                    'display' => 1,
                    'date' => date('Y-m-d'),
                ]);
            }
            if ($numbers == 1) {
                $featureObj->create([
                    'type' => 'numbers',
                    'entity_id' => $id,
                    'name_ar' => 1,
                    'name_en' => 1,
                    'display' => 1,
                    'date' => date('Y-m-d'),
                ]);
            }
            if ($covered == 1) {
                $featureObj->create([
                    'type' => 'covered',
                    'entity_id' => $id,
                    'name_ar' => 1,
                    'name_en' => 1,
                    'display' => 1,
                    'date' => date('Y-m-d'),
                ]);
            }
            if ($shower == 1) {
                $featureObj->create([
                    'type' => 'shower',
                    'entity_id' => $id,
                    'name_ar' => 1,
                    'name_en' => 1,
                    'display' => 1,
                    'date' => date('Y-m-d'),
                ]);
            }
            if ($water == 1) {
                $featureObj->create([
                    'type' => 'water',
                    'entity_id' => $id,
                    'name_ar' => 1,
                    'name_en' => 1,
                    'display' => 1,
                    'date' => date('Y-m-d'),
                ]);
            }
            if ($paidWater == 1) {
                $featureObj->create([
                    'type' => 'paidWater',
                    'entity_id' => $id,
                    'name_ar' => 1,
                    'name_en' => 1,
                    'display' => 1,
                    'date' => date('Y-m-d'),
                ]);
            }
            if ($wc == 1) {
                $featureObj->create([
                    'type' => 'wc',
                    'entity_id' => $id,
                    'name_ar' => 1,
                    'name_en' => 1,
                    'display' => 1,
                    'date' => date('Y-m-d'),
                ]);
            }

            if (count($payment_ar) > 0) {
                foreach ($payment_ar as $i => $pay) {
                    $featureObj->create([
                        'type' => 'payment',
                        'entity_id' => $id,
                        'name_ar' => $pay,
                        'name_en' => $payment_en[$i],
                        'display' => 1,
                        'date' => date('Y-m-d'),
                    ]);
                }
            }
            
            if (count($size_ar) > 0) {
                foreach ($size_ar as $i => $size) {
                    $featureObj->create([
                        'type' => 'size',
                        'entity_id' => $id,
                        'name_ar' => $size,
                        'name_en' => $size_en[$i],
                        'display' => 1,
                        'date' => date('Y-m-d'),
                    ]);
                }
            }
            
            if (count($period_ar) > 0) {
                foreach ($period_ar as $i => $period) {
                    $featureObj->create([
                        'type' => 'period',
                        'entity_id' => $id,
                        'name_ar' => $period,
                        'name_en' => $period_en[$i],
                        'display' => 1,
                        'date' => date('Y-m-d'),
                    ]);
                }
            }

            include 'models/EntityImage.php';
            $entityImageObj = new EntityImage();
            if (isset($_FILES['image']['name']) && count($_FILES['image']['name']) > 0) {

                foreach ($_FILES['image']['name'] as $i => $photo_name) {
                    if ($photo_name) {
                        $target_dir = "api/uploads/stadiums/" . $id;
                        $target_file = $target_dir . "/" . basename($photo_name);
                        $photo_tmp = $_FILES['image']['tmp_name'][$i];
                        $get_image_ext = explode('.', $photo_name);
                        $image_ext = strtolower(end($get_image_ext));

                        if (!file_exists($target_dir)) {
                            mkdir($target_dir);
                        }

                        if (strtolower($image_ext) == 'png') {
                            $source = imagecreatefrompng($photo_tmp);
                        }

                        if (strtolower($image_ext) == 'jpg' || strtolower($image_ext) == 'jpeg') {
                            $source = imagecreatefromjpeg($photo_tmp);
                        }

                        list($width_min, $height_min) = getimagesize($photo_tmp);
                        $newWidth = 350;
                        $newHeight = ($newWidth / $width_min) * $height_min;

                        $tmp_min = imagecreatetruecolor($newWidth, $newHeight);

                        imagecopyresampled($tmp_min, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width_min, $height_min);
                        imagejpeg($tmp_min, $target_file, 50);


                        $image_name_update = $photo_name;
                        $image_tmp_update = $_FILES['image']['tmp_name'][$i];

                        if ($_SERVER['SERVER_NAME'] == 'localhost') {
                            $image_path = "http://localhost/poolbhr/api/uploads/pools/" . $id . '/' . $image_name_update;
                            $image_database = "http://localhost/poolbhr/api/uploads/pools/{$id}/{$image_name_update}";
                        } else {
                            $image_path = "http://poolbhr.com/admin/api/uploads/pools/" . $id . '/' . $image_name_update;
                            $image_database = "http://poolbhr.com/admin/api/uploads/pools/{$id}/{$image_name_update}";
                        }

                        $entityImageObj->create([
                            'entity_id' => $id,
                            'image' => $image_database,
                            'type' => 'image',
                            'date' => date('Y-m-d'),
                        ]);
                    }
                }
            }

            if (isset($_FILES['video']['name']) && count($_FILES['video']['name']) > 0) {

                foreach ($_FILES['video']['name'] as $i => $video_name) {
                    if ($video_name) {
                        $target_dir = "api/uploads/stadiums/" . $id;
                        $target_file = $target_dir . "/" . basename($video_name);

                        if (!file_exists($target_dir)) {
                            mkdir($target_dir);
                        }

                        if (move_uploaded_file($_FILES["video"]["tmp_name"][$i], $target_file)) {
                            $msg = "The file " . basename($video_name) . " has been uploaded.";
                        }

                        $image_name_update = $video_name;
                        $image_tmp_update = $_FILES['video']['tmp_name'][$i];

                        if ($_SERVER['SERVER_NAME'] == 'localhost') {
                            $image_path = "http://localhost/poolbhr/api/uploads/stadiums/" . $id . '/' . $image_name_update;
                            $image_database = "http://localhost/poolbhr/api/uploads/stadiums/{$id}/{$image_name_update}";
                        } else {
                            $image_path = "http://poolbhr.com/admin/api/uploads/stadiums/" . $id . '/' . $image_name_update;
                            $image_database = "http://poolbhr.com/admin/api/uploads/stadiums/{$id}/{$image_name_update}";
                        }

                        $entityImageObj->create([
                            'entity_id' => $id,
                            'image' => $image_database,
                            'type' => 'video',
                            'date' => date('Y-m-d'),
                        ]);
                    }
                }
            }


            echo get_success(trans('addedSuccessfully'));
        } else {
            echo get_error(trans('somethingWrong'));
        }
    }
}
?>
<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<?php include("include/leftsidebar.php"); ?>
<div class="wrapper">
    <div class="container">    <!-- Start content -->
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title"><?php echo trans('stadiums'); ?></h4>
                <ol class="breadcrumb">
                    <li>
                        <a href="entities_view.php?lang=<?php echo $lang; ?>&type=<?php echo $_GET['type']; ?>"><?php echo trans('stadiums'); ?></a>
                    </li>
                    <li class="active">
                        <?php echo trans('addStadium'); ?>
                    </li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card-box">

                    <form method="POST" enctype="multipart/form-data" data-parsley-validate novalidate>

                        <div class="form-group col-md-3">
                            <label><?php echo trans('name_ar'); ?></label>
                            <input type="text" class="form-control" name="name_ar" required value="<?php echo old('name_ar'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('name_en'); ?></label>
                            <input type="text" class="form-control" name="name_en" required value="<?php echo old('name_en'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('region'); ?></label>
                            <select type="text" class="form-control" id="discountType" name="discountType">
                                <option value="0">---</option>
                                <?php
                                include_once 'models/Region.php';
                                $regionObj = new Region();
                                $regions = $regionObj->getAll();
                                foreach ($regions as $region) {
                                    ?>
                                    <option value="<?= $region['id'] ?>"><?= $region['name_' . $lang] ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('code'); ?></label>
                            <input type="text" class="form-control" name="code" value="<?php echo old('code'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('price'); ?></label>
                            <input type="text" class="form-control" name="price" required value="<?php echo old('price'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('price_weekend'); ?></label>
                            <input type="text" class="form-control" name="price_weekend" value="<?php echo old('price_weekend'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('discount'); ?></label>
                            <select type="text" class="form-control" id="discountType" name="discountType">
                                <option value="0"><?php echo trans('no'); ?></option>
                                <option value="1"><?php echo trans('yes'); ?></option>
                            </select>
                        </div>
                        <div class="form-group col-md-3" id="discount-parent" style="display: none">
                            <label><?php echo trans('discount'); ?></label>
                            <input type="number" class="form-control" name="discount" value="0">
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('weekendDiscount'); ?></label>
                            <select type="text" class="form-control" id="weekendDiscountType" name="weekendDiscountType">
                                <option value="0"><?php echo trans('no'); ?></option>
                                <option value="1"><?php echo trans('yes'); ?></option>
                            </select>
                        </div>
                        <div class="form-group col-md-3" id="weekend-discount-parent" style="display: none">
                            <label><?php echo trans('weekendDiscount'); ?></label>
                            <input type="number" class="form-control" name="weekendDiscount" value="0">
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group col-md-6">
                            <label><?php echo trans('desc_ar'); ?></label>
                            <textarea name="desc_ar" class="form-control"><?php echo old('desc_ar'); ?></textarea>
                        </div>
                        <div class="form-group col-md-6">
                            <label><?php echo trans('desc_en'); ?></label>
                            <textarea name="desc_en" class="form-control"><?php echo old('desc_en'); ?></textarea>
                        </div>
                        <div class="form-group col-md-6">
                            <label><?php echo trans('condition_rules_ar'); ?></label>
                            <textarea name="condition_rules_ar" class="form-control"><?php echo old('condition_rules_ar'); ?></textarea>
                        </div>
                        <div class="form-group col-md-6">
                            <label><?php echo trans('condition_rules_en'); ?></label>
                            <textarea name="condition_rules_en" class="form-control"><?php echo old('condition_rules_en'); ?></textarea>
                        </div>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('check_availability'); ?>*</label>
                            <input id="check_availability" checked name="check_availability" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div class="clearfix"></div>

                        <div class="form-group col-sm-12" id="map" style="height: 300px"></div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('lat'); ?></label>
                            <input type="text" id="lat" class="form-control" name="lat">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('long'); ?></label>
                            <input type="text" id="lang" class="form-control" name="long">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('address_ar'); ?></label>
                            <input type="text" class="form-control" name="address_ar" value="<?php echo old('address_ar'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('address_en'); ?></label>
                            <input type="text" class="form-control" name="address_en" value="<?php echo old('address_en'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('space'); ?></label>
                            <input type="text" class="form-control" name="space" value="<?php echo old('space'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('mobile'); ?></label>
                            <input type="text" class="form-control" name="mobile" value="<?php echo old('mobile'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('whatsapp'); ?></label>
                            <input type="text" class="form-control" name="whatsapp" value="<?php echo old('whatsapp'); ?>">
                        </div>
                        <div class="form-group col-md-3">
                            <label><?php echo trans('belongs_to'); ?></label>
                            <select type="text" class="form-control" name="user_id">
                                <option value="0"><?php echo trans('public'); ?></option>
                                <?php
                                $users = $userObj->getUsers();
                                foreach ($users as $user) {
                                    ?>
                                    <option value="<?php echo $user['id']; ?>"><?php echo $user['username']; ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="clearfix"></div>
                        <div class="optionBox">
                            <div class="form-group m-b-0 image col-md-6">
                                <label class="control-label"> <?php echo trans('images'); ?>*</label>
                                <input type="file" required name="image[]" id="image" class="filestyle" multiple data-buttonname="btn-primary">
                            </div>
                            <div class="form-group m-b-0 image col-md-6">
                                <label class="control-label"> <?php echo trans('videos'); ?></label>
                                <input type="file" name="video[]" id="video" class="filestyle" multiple data-buttonname="btn-primary">
                            </div>
<!--                            <div class="image">-->
<!--                                <span class="btn btn-primary addImage">+</span>-->
<!--                            </div>-->
                        </div>
                        <div class="clearfix"></div>
                        <br>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('ball'); ?>*</label>
                            <input name="ball" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('numbers'); ?>*</label>
                            <input name="numbers" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('covered'); ?>*</label>
                            <input name="covered" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('shower'); ?>*</label>
                            <input name="shower" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('water'); ?>*</label>
                            <input id="water-switch" checked name="water" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div id="paidWater-switch" class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('paidWater'); ?>*</label>
                            <input name="paidWater" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('wc'); ?>*</label>
                            <input name="wc" type="checkbox" data-plugin="switchery" data-color="#81c868"/>
                        </div>
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('payment'); ?>*</label>
                            <div class="block">
                                <input name="payment_ar[]" type="text"  parsley-trigger="change" required placeholder="<?php echo trans('name_ar'); ?>" class="form-control thisField">
                                <input name="payment_en[]" type="text" parsley-trigger="change" required placeholder="<?php echo trans('name_en'); ?>" class="form-control thisField">

                            </div>
                            <div class="block">
                                <span class="btn btn-primary add">+</span>
                            </div>
                        </div>
                        
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('sizes'); ?>*</label>
                            <div class="size">
                                <input name="size_ar[]" type="text"  parsley-trigger="change" required placeholder="<?php echo trans('name_ar'); ?>" class="form-control thisField">
                                <input name="size_en[]" type="text" parsley-trigger="change" required placeholder="<?php echo trans('name_en'); ?>" class="form-control thisField">

                            </div>
                            <div class="size">
                                <span class="btn btn-primary addSize">+</span>
                            </div>
                        </div>
                        
                        <div class="form-group optionBox" style="position: relative;">
                            <label class="control-label"><?php echo trans('periods'); ?>*</label>
                            <div class="period">
                                <input name="period_ar[]" type="text"  parsley-trigger="change" required placeholder="<?php echo trans('name_ar'); ?>" class="form-control thisField">
                                <input name="period_en[]" type="text" parsley-trigger="change" required placeholder="<?php echo trans('name_en'); ?>" class="form-control thisField">

                            </div>
                            <div class="period">
                                <span class="btn btn-primary addPeriod">+</span>
                            </div>
                        </div>

                        <div class="form-group text-left m-b-0">
                            <button class="btn btn-primary waves-effect waves-light" type="submit" name="submit" id="submit"> <?php echo trans('add'); ?></button>
                        </div>

                        <br />

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php include("include/footer_text.php"); ?>
<!-- END wrapper -->
<?php include("include/footer.php"); ?>
<style>
    div.block > span.add-more {
        padding: 1vh;
    }
</style>
<script>
    $("#navigation ul>li").removeClass("active");
    $("#item3").addClass("active");
    $('.select2me').select2({
        placeholder: "Select",
        width: 'auto',
        allowClear: true
    });

    $('#water-switch').change(function () {
        $('#paidWater-switch').toggle();
    })
</script>
<script>

    $(".select2, .select2-multiple").select2();

</script>
</script>
<script type="text/javascript">
    $('.add').on('click', function () {
        $('.block:last').before(`<div class="block"><input name="payment_ar[]" type="text"  parsley-trigger="change" required placeholder="<?php echo trans('name_ar'); ?>" class="form-control thisField">
                <input name="payment_en[]" type="text" parsley-trigger="change" required placeholder="<?php trans('name_en'); ?>" class="form-control thisField"><button class="btn add-remove remove-me remove red" type="button">-</button></div>`);
    });

    $('.addPeriod').on('click', function () {
        $('.period:last').before(`<div class="period">
            <input name="period_ar[]" type="text"  parsley-trigger="change" required placeholder="<?php echo trans('name_ar'); ?>" class="form-control thisField">
            <input name="period_en[]" type="text" parsley-trigger="change" required placeholder="<?php echo trans('name_en'); ?>" class="form-control thisField">
            <button class="btn add-remove remove-me remove red" type="button">-</button></div>`);
    });
    
    $('.addSize').on('click', function () {
        $('.size:last').before(`<div class="size">
            <input name="size_ar[]" type="text"  parsley-trigger="change" required placeholder="<?php echo trans('name_ar'); ?>" class="form-control thisField">
            <input name="size_en[]" type="text" parsley-trigger="change" required placeholder="<?php echo trans('name_en'); ?>" class="form-control thisField">
            <button class="btn add-remove remove-me remove red" type="button">-</button></div>`);
    });

    $('.addImage').on('click', function () {
        $('.image:last').before(`<div class="form-group m-b-0 image">
                    <br>
                    <input type="file" name="image[]" id="image" class="filestyle" multiple data-buttonname="btn-primary" required><button class="btn add-remove remove-me remove red" type="button">-</button></div>`);
    });
    $('.optionBox').on('click', '.remove', function () {
        $(this).parent().remove();
    });

$('#discountType').change(function () {
    if ($(this).val() == 1) {
        $('#discount-parent').show();
    } else {
        $('#discount-parent').hide();
    }
})

$('#weekendDiscountType').change(function () {
    if ($(this).val() == 1) {
        $('#weekend-discount-parent').show();
    } else {
        $('#weekend-discount-parent').hide();
    }
})
</script>

<script>
    var map;
    var markers = [];

    function initMap() {
        var haightAshbury = {lat: 26.22170100683176, lng: 50.58556788820532};

        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15,
            center: haightAshbury,
            mapTypeId: 'terrain'
        });

        $('#lat').val('26.22170100683176');
        $('#lang').val('50.58556788820532');
        // This event listener will call addMarker() when the map is clicked.
        map.addListener('click', function(event) {
            addMarker(event.latLng);
            var latitude = event.latLng.lat();
            var longitude = event.latLng.lng();
            $('#lat').val(latitude);
            $('#lang').val(longitude);

        });

        // Adds a marker at the center of the map.
        addMarker(haightAshbury);
    }

    // Adds a marker to the map and push to the array.
    function addMarker(location) {
        clearMarkers();
        var marker = new google.maps.Marker({
            position: location,
            map: map
        });
        markers.push(marker);
    }

    // Sets the map on all markers in the array.
    function setMapOnAll(map) {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(map);
        }
    }

    // Removes the markers from the map, but keeps them in the array.
    function clearMarkers() {
        setMapOnAll(null);
    }

    // Shows any markers currently in the array.
    function showMarkers() {
        setMapOnAll(map);
    }

    // Deletes all markers in the array by removing references to them.
    function deleteMarkers() {
        clearMarkers();
        markers = [];
    }
</script>
<script>
    $(document).ready(function () {


        $("#lat").on("input", function(){
            // // Print entered value in a div box
            var lat=$("#lat").val();
            var lang=$("#lang").val();

            var haightAshbury =  {lat: 26.22170100683176, lng: 50.58556788820532};
            haightAshbury["lat"]=Number(lat);
            haightAshbury["lng"]=Number(lang);

            // Adds a marker at the center of the map.
            addMarker(haightAshbury);


            console.log(haightAshbury);
        });


        $("#lang").on("input", function(){
            // // Print entered value in a div box
            var lat=$("#lat").val();
            var lang=$("#lang").val();

            var haightAshbury =  {lat: 26.22170100683176, lng: 50.58556788820532};
            haightAshbury["lat"]=Number(lat);
            haightAshbury["lng"]=Number(lang);

            // Adds a marker at the center of the map.
            addMarker(haightAshbury);


            console.log(haightAshbury);
        });



        $("#cssmenu ul>li").removeClass("active");
        $("#item8").addClass("active");
    });
</script>

<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDeuOTzbTLT2EHbvjzyHCckOiIpnTRZjSY&callback=initMap">
</script>

</body>
</html>