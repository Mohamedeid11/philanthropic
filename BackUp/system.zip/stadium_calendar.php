<?php
include("config.php");
if (!loggedin()) {
    header("Location: login.php");
    exit();
}

include 'models/CalendarStadium.php';
$calendarObj = new CalendarStadium();
if (isset($_POST['submit'])) {

    $date = $_POST['date'];
    $stadium_id = $_POST['entity'];
    $from = $_POST['from'];
    $to = $_POST['to'];
    $price = $_POST['price'];
    $paid = $_POST['paid'];
    $remain = $_POST['remain'];
    $client_name = $_POST['client_name'];
    $client_mobile = $_POST['client_mobile'];

    $calendarObj->create([
        'stadium_id' => $stadium_id,
        'close_date' => $date,
        'from_time' => $from,
        'to_time' => $to,
        'price' => $price,
        'paid' => $paid,
        'remain' => $remain,
        'client_name' => $client_name,
        'client_mobile' => $client_mobile,
        'created_by' => 'admin',
        'date' => date('Y-m-d'),
    ]);
    echo get_success(trans('addedSuccessfully'));
}
?>
<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<?php include("include/leftsidebar.php"); ?>

<style>
    .notifyjs-metro-base {
        position: relative;
        min-height: 52px;
        min-width: 250px;
        max-width: 400px;
        color: #444;
        border-radius: 3px;
        -webkit-border-radius: 3px;
        box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.2);
        -webkit-animation: dropdownOpen 0.3s ease-out;
        -o-animation: dropdownOpen 0.3s ease-out;
        animation: dropdownOpen 0.3s ease-out;
    }

    .notifyjs-metro-error {
        color: #fafafa !important;
        background-color: #f05050;
        border: 1px solid #ef5350;
    }

    .notifyjs-metro-success {
        color: #fafafa !important;
        background-color: #81c868;
        border: 1px solid #33b86c;
    }
</style>

<div class="wrapper">

    <!-- Start right Content here -->

    <div class="deleteData"></div>

    <div class="container">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title"><?php echo trans('stadiumReservations'); ?></h4>
                <ol class="breadcrumb">
                    <li><a href="calendar.php?lang=<?php echo $lang; ?>"><?php echo trans('stadiumReservations'); ?></a></li>
                    <li class="active"><?php echo trans('calendar'); ?></li>
                </ol>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div style="width: 30px; height: 30px; display: inline-block; background-color: #419af5"></div>
                <h5 style="display: inline-block"><?php echo trans('createdByAdmin'); ?></h5>
            </div>
            <div class="col-sm-6">
                <div style="width: 30px; height: 30px; display: inline-block; background-color: #29612d"></div>
                <h5 style="display: inline-block"><?php echo trans('createdByUser'); ?></h5>
            </div>
        </div>

        <div class="panel">
            <div class="panel-body">
                <div class="">
                    <div class="col-lg-12">
                        <div class="card-box">
                            <div id="calendar" class="col-centered" style="max-width: 100%">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="ModalAdd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form class="form-horizontal" method="POST" action="">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel"><?php echo trans('reservations'); ?></h4>
                        </div>
                        <div id="reserv">

                        </div>
                        <div class = "modal-footer">
                            <button type = "button" class = "btn btn-default" data-dismiss = "modal"><?php echo trans('cancel'); ?></button>
                            <button type ="button" class = "btn btn-default" id="close_day"><?php echo trans('addReservation'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="ModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class = "modal-dialog" role = "document">
                <div class = "modal-content">
                    <form class = "form-horizontal"  method="POST" enctype="multipart/form-data" data-parsley-validate novalidate>
                        <br>
                        <input type="hidden" name="date" id="block_date">
                        <h1 id="show_date"></h1>
                        <div id="details">
                            <input type="hidden" name="other_id_session" id="other_id_session" class="other_id_session" value="">
                            <div class="col-md-6">
                                <label class="control-label"><?php echo trans('stadiums'); ?></label>
                                <select class="form-control" name="entity" required >
                                    <option value=''>---</option>

                                    <?php
                                    include 'models/Entity.php';
                                    $entityObj = new Entity();
                                    $stadiums = $entityObj->getStadiums(0,0,'');

                                    foreach ($stadiums as $stadium) {
                                        ?>
                                        <option value='<?php echo $stadium['id']; ?>'>
                                            <?php echo $stadium['name_' . $lang]; ?>
                                        </option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="control-label"><?php echo trans('from'); ?></label>
                                <input type="time" name="from" class="form-control">
                            </div>
                            <div class="col-md-6">
                                <label class="control-label"><?php echo trans('to'); ?></label>
                                <input type="time" name="to" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label"><?php echo trans('price'); ?></label>
                                <input class="form-control" name="price" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label"><?php echo trans('paid'); ?></label>
                                <input class="form-control" name="paid" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label"><?php echo trans('remain'); ?></label>
                                <input class="form-control" name="remain" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label"><?php echo trans('client_name'); ?></label>
                                <input class="form-control" name="client_name" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label"><?php echo trans('client_mobile'); ?></label>
                                <input class="form-control" name="client_mobile" required>
                            </div>
                            <div class="clearfix" style="margin-bottom: 20px"></div>
                        </div>

                        <div class="form-group text-right m-b-0">
                            <button type = "button" class = "btn btn-default" data-dismiss = "modal"><?php echo trans('cancel'); ?></button>
                            <button class="btn btn-primary waves-effect waves-light" type="submit" name="submit"><?php echo trans('save'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include("include/footer_text.php"); ?>
</div>
<!-- END wrapper -->
<?php include("include/footer.php"); ?>
<script>
    $('#calendar').fullCalendar({
        eventLimit: true, // allow "more" link when too many events
        selectable: true,
        firstDay: 6,
        select: function (start) {
            $('#ModalAdd').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
            $('#ModalAdd').attr('data-date', moment(start).format('YYYY-MM-DD'));
            var close_date = moment(start).format('YYYY-MM-DD');
            $("#block_date").val(close_date);
            $("#show_date").html(close_date);
            $.ajax({
                url: "getReservation.php",
                type: "POST",
                data: {close_date: close_date, type: 'stadium'},
                success: function (data)
                {
                    let xx;
                    if (JSON.parse(data).length > 0) {
                        xx = `
                        <div class="table-responsive">
                        <table class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable_info">
                            <tr>
                                <th><?php echo trans('stadiums'); ?></th>
                                <th><?php echo trans('from'); ?></th>
                                <th><?php echo trans('to'); ?></th>
                                <th><?php echo trans('price'); ?></th>
                                <th><?php echo trans('paid'); ?></th>
                                <th><?php echo trans('remain'); ?></th>
                                <th><?php echo trans('client_name'); ?></th>
                                <th><?php echo trans('client_mobile'); ?></th>
                                <th></th>
                            </tr>
                        `;
                        for (let i = 0; i < JSON.parse(data).length; i++) {
                            xx += `
                                <tr>
                                    <td>${JSON.parse(data)[i].name_<?php echo $lang; ?>}</td>
                                    <td>${JSON.parse(data)[i].from_time}</td>
                                    <td>${JSON.parse(data)[i].to_time}</td>
                                    <td>${parseFloat(JSON.parse(data)[i].price)} BD</td>
                                    <td>${parseFloat(JSON.parse(data)[i].paid)} BD</td>
                                    <td>${parseFloat(JSON.parse(data)[i].remain)} BD</td>
                                    <td>${JSON.parse(data)[i].client_name}</td>
                                    <td>${JSON.parse(data)[i].client_mobile}</td>
                                    <td>
                                        <a href="reservation_details.php?type=4&id=${JSON.parse(data)[i].id}"><i class="fa fa-eye"></i></a>
                                        <a href="javascript:;" data-id="${JSON.parse(data)[i].id}" class="deletemsg" ><i class="fa fa-trash-o"></i></a>
                                    </td>
                                </tr>
                            `
                        }
                        xx += `</table></div>`
                    } else {
                        xx = '<h4><?php echo trans('NoReservationOnThisDay'); ?></h4>'
                    }
                    $("#reserv").empty().append(xx);
                }
            });
            $('#ModalAdd').modal('show');
            $('body').on('click', '#close_day', function () {
                $('#ModalEdit').modal('show');
            });
        },
        events: [
            <?php
            $events = $calendarObj->getAll(0,0,'');
            foreach ($events as $event) {
            ?>
            {
                title: '<?php echo $event['name_' . $lang] ?>',
                start: '<?php echo $event['close_date']; ?>',
                end: '<?php echo $event['close_date']; ?>',
                display: 'background',
                color: '<?php echo $event['created_by'] == 'admin' ? '#419af5' : '#29612d'; ?>'
            },
            <?php
            }
            ?>
        ]
    });

    $('body').on('click', '.deletemsg', function () {
        let id = $(this).attr('data-id');
        bootbox.dialog({
            message: "<?php echo trans('askDelete'); ?>",
            title: "<?php echo trans('confirmDelete'); ?>", buttons: {
                danger: {
                    label: "<?php echo trans('cancel'); ?>",
                    className: "btn-danger"
                },
                main: {
                    label: "<?php echo trans('delete'); ?>", className: "btn-primary",
                    callback: function () {
                        //do something else
                        $.ajax({
                            type: "POST",
                            url: "delete_reservation.php",
                            data: {
                                type: "stadium",
                                id: id
                            },
                            dataType: 'text',
                            cache: false,
                            success: function (data) {
                                location.reload();
                            }
                        });
                    }
                }
            }
        });
    });


    function edit(event) {

    }

</script>

<script>
    $("#cssmenu ul>li").removeClass("active");
    $("#item4").addClass("active");
</script>

</body>
</html>