<?php
include("config.php");
if (!loggedin()) {
    header("Location: login.php");
    exit();
} if ($_SESSION['user_role'] != 'admin') {
    header("Location: index.php");
    exit();
}
include "models/Region.php";

if (isset($_POST['region_update'])) {

    $id = $_POST['id'];
    $name_ar = $_POST['name_ar'];
    $name_en = $_POST['name_en'];

    $regionObj = new Region();
    $region = $regionObj->getById($id);

    $errors = array();

    if (empty($name_ar) || empty($name_en)) {
        $errors[] = trans('PleaseEnterAllFields');
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            //echo $error, '<br />';
            echo get_error($error);
        }
    } else {
        $update = $regionObj->update([
            'name_ar' => $name_ar,
            'name_en' => $name_en,
            'id' => $id
        ]);

        if ($update) {
            echo get_success(trans('updatedSuccessfully'));
        } else {
            echo get_error(trans('somethingWrong'));
        }
    }
}
?>

<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<?php include("include/leftsidebar.php"); ?>
<div class="wrapper">
    <div class="container">    <!-- Start content -->
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title"><?php echo trans('regions'); ?></h4>
                <ol class="breadcrumb">
                    <li>
                        <a href="client_edit.php"><?php echo trans('regions'); ?></a>
                    </li>
                    <li class="active">
                        <?php echo trans('editRegion'); ?>
                    </li>
                </ol>
            </div>
        </div>
        <?php
        if ($_GET['id']) {

            $id = $_GET['id'];

            $regionObj = new Region();
            $row_select = $regionObj->getById($id);

            $client_id = $row_select['id'];
            $name_ar = $row_select['name_ar'];
            $name_en = $row_select['name_en'];

            if ($row_select) {
                ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <form method="POST" enctype="multipart/form-data" data-parsley-validate novalidate>
                                <input type="hidden" name="id" id="id" parsley-trigger="change" required value="<?php echo $id; ?>" class="form-control">
                                <div class="form-group col-md-6">
                                    <label for="name_ar"><?php echo trans('name_ar'); ?></label>
                                    <input type="text" name="name_ar" id="name_ar" parsley-trigger="change" required value="<?php echo $name_ar; ?>" class="form-control">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name_en"><?php echo trans('name_en'); ?></label>
                                    <input type="text" name="name_en" id="name_en" parsley-trigger="change" required value="<?php echo $name_en; ?>" class="form-control">
                                </div>
                                <div class="clearfix"></div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="text-center p-20">
                                            <button type="reset" class="btn w-sm btn-white waves-effect"><?php echo trans('cancel'); ?></button>
                                            <button type="submit" name="region_update" class="btn w-sm btn-default waves-effect waves-light"><?php echo trans('update'); ?></button>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <script type="text/javascript">
                    $(document).ready(function () {
                        $('.image-popup').magnificPopup({
                            type: 'image',
                            closeOnContentClick: true,
                            mainClass: 'mfp-fade',
                            gallery: {
                                enabled: true,
                                navigateByImgClick: true,
                                preload: [0, 1] // Will preload 0 - before current, and 1 after the current image
                            }
                        });
                    });
                </script>
                <?php
            }
        }
        ?>


    </div>
</div>
<?php include("include/footer_text.php"); ?>

<?php include("include/footer.php"); ?>
<script>
    $('.select2me').select2({
        placeholder: "Select",
        width: 'auto',
        allowClear: true
    });
</script>

</body>
</html>