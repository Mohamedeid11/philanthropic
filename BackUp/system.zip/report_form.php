<?php
include("config.php");
if (!loggedin()) {
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<style>
    .datepicker {
        z-index: 9999;
    }
</style>
<body class="fixed-left">
<div id="wrapper" style="padding-top: 180px">

    <!-- Left Sidebar Start -->
    <?php include("include/leftsidebar.php"); ?>
    <!-- Left Sidebar End -->

    <!-- Start right Content here -->

    <div class="deleteData"></div>

    <div class="content-page">
        <!-- Start content -->
        <div class="content">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <h4 class="page-title"><?php echo trans('report'); ?></h4>
                        <ol class="breadcrumb">
                            <li><a href=""><?php echo trans('report'); ?></a></li>
                            <li class="active"><?php echo trans('report'); ?></li>
                        </ol>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-box">
                            <h4 class="m-t-0 header-title"><b><?php echo trans('search'); ?></b></h4>
                            <p class="text-muted font-13 m-b-30"></p>
                            <form method="post" action="print.php" enctype="multipart/form-data" target="_blank" data-parsley-validate>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label ><?php echo trans('date'); ?></label>
                                        <div class="input-group  date-picker input-daterange" data-date="10/11/2012" data-date-format="yyyy-mm-dd" >
                                            <input type="text" class="form-control input-sm" readonly="" name="from" id="date_report_from">
                                            <span class="input-group-addon"><?php echo trans('to'); ?></span>
                                            <input type="text" class="form-control input-sm" readonly="" name="to" id="date_report_to">
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <br>
                                    <div class="form-group col-md-3">
                                        <label for="select_payment_type"><?php echo trans('categories'); ?></label>
                                        <select class="form-control select2me" name="category" id="category"  parsley-trigger="change">
                                            <option value=''><?php echo trans('all'); ?></option>
                                            <?php
                                            include 'models/Category.php';
                                            $categoryObj = new Category();
                                            $categories = $categoryObj->getActive();
                                            foreach ($categories as $category) {
                                            ?>
                                            <option value='<?php echo $category['id']; ?>'><?php echo $category['name_' . $lang]; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="select_payment_type"><?php echo trans('categories'); ?></label>
                                        <select class="form-control select2me" name="entity" id="entities"  parsley-trigger="change">
                                            <option value=''><?php echo trans('all'); ?></option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12" style="margin-top:60px;width:100%;clear:both;">
                                        <button class="btn btn-primary waves-effect waves-light" type="submit" name="submit"><?php echo trans('search'); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <?php include("include/footer_text.php"); ?>

    </div>
    <!-- End Right content here -->
</div>
<!-- END wrapper -->
<?php include("include/footer.php"); ?>

<script>
    $(document).ready(function () {
        $("#cssmenu ul>li").removeClass("active");
        $("#item013").addClass("active");
    });
</script>
<script type="text/javascript">
    $('.date-picker').datepicker();
    $('.select2me').select2({
        placeholder: "Select",
        width: 'auto',
        allowClear: true
    });

    $('#category').change(function () {
        let id = $(this).val();
        $.ajax({
            type: "POST",
            url: "entity.php",
            data: {
                type: "getEntity",
                id: id,
            },
            dataType: 'text',
            cache: false,
            success: function (data) {
                let xx = `<option value="">---</option>`;
                if (JSON.parse(data).length > 0) {
                   for (let i = 0; i < JSON.parse(data).length; i++) {
                       xx += `<option value="${JSON.parse(data)[i].id}">
                            ${JSON.parse(data)[i].name_<?php echo $lang; ?>}
                        </option>`
                   }
                }
                $("#entities").empty().append(xx);
            }
        });
    });
</script>

</body>
</html>