<?php
include("config.php");
if (!loggedin()) {
    header("Location: login.php");
    exit();
} if ($_SESSION['user_role'] != 'admin') {
    header("Location: index.php");
    exit();
}
if (isset($_POST['submit'])) {

    $name_ar = mysqli_real_escape_string($con, trim($_POST['name_ar']));
    $name_en = mysqli_real_escape_string($con, trim($_POST['name_en']));


    $errors = array();
    include 'models/Region.php';
    $regionObj = new Region();

    if (empty($name_ar) || empty($name_en)) {
        $errors[] = trans('PleaseEnterAllFields');
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            //echo $error, '<br />';
            echo get_error($error);
        }
    } else {

        $regionObj->create([
            'name_ar'   => $name_ar,
            'name_en'   => $name_en,
            'date'      => date('Y-m-d H:i'),
        ]);
        echo get_success(trans('addedSuccessfully'));
    }
}
?>
<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<?php include("include/leftsidebar.php"); ?>
<div class="wrapper">
    <div class="container">    <!-- Start content -->
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title"><?php echo trans('regions'); ?></h4>
                <ol class="breadcrumb">
                    <li>
                        <a href="client_view.php"><?php echo trans('regions'); ?></a>
                    </li>
                    <li class="active">
                        <?php echo trans('addRegion'); ?>
                    </li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card-box">
                    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" data-parsley-validate novalidate>
                        <div class="form-group col-md-6">
                            <label for="name_ar"><?php echo trans('name_ar'); ?></label>
                            <input type="text" name="name_ar" value="<?php echo old('name_ar'); ?>" parsley-trigger="change" required placeholder="<?php echo trans('name_ar'); ?>" class="form-control" >
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name_en"><?php echo trans('name_en'); ?></label>
                            <input type="text" name="name_en" value="<?php echo old('name_en'); ?>" parsley-trigger="change" required placeholder="<?php echo trans('name_en'); ?>" class="form-control" >
                        </div>
                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="text-center p-20">
                                    <button type="reset" class="btn w-sm btn-white waves-effect"><?php echo trans('cancel'); ?></button>
                                    <button type="submit" name="submit" class="btn w-sm btn-default waves-effect waves-light"><?php echo trans('add'); ?></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include("include/footer_text.php"); ?>

<?php include("include/footer.php"); ?>
<script>
    $('.select2me').select2({
        placeholder: "Select",
        width: 'auto',
        allowClear: true
    });
</script>

</body>
</html>