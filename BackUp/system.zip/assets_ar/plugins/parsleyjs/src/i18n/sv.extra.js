window.ParsleyConfig = window.ParsleyConfig || {};
window.ParsleyConfig.i18n = window.ParsleyConfig.i18n || {};

window.ParsleyConfig.i18n.sv = jQuery.extend(window.ParsleyConfig.i18n.sv || {}, {
  dateiso: "Ange ett giltigt datum (ÅÅÅÅ-MM-DD)."
});
