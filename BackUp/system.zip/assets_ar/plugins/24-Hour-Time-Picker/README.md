# jquery-hunterTimePicker

HunterTimePicker 时间选择组件，可以选择小时和分钟，小时为24小时制，分钟间隔为5分钟。
