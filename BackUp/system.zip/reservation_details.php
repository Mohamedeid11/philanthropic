<?php
include("config.php");
if (!loggedin()) {
    header("location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<?php include("include/heads.php"); ?>
<style>
    .pager  .active   a {
        background-color: #448bf4;

    }
</style>
<?php include("include/leftsidebar.php"); ?>

<!-- Start right Content here -->
<div class="deleteData"></div>

<div class="wrapper">
    <div class="container">    <!-- Start content -->
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title"> <?php echo trans('reservations'); ?> </h4>
                <ol class="breadcrumb">
                    <li>
                        <a href=""> <?php echo trans('reservations'); ?> </a>
                    </li>
                    <li class="active">
                        <?php echo trans('reservationDetails'); ?>
                    </li>
                </ol>
            </div>
            <?php

            if(isset($_GET['id']) && isset($_GET['type'])){
                if ($_GET['type'] == 1) {
                    include 'models/CalendarPool.php';
                    $calendarObj = new CalendarPool();
                } elseif ($_GET['type'] == 2) {
                    include 'models/CalendarChalet.php';
                    $calendarObj = new CalendarChalet();
                } elseif ($_GET['type'] == 3) {
                    include 'models/CalendarCamp.php';
                    $calendarObj = new CalendarCamp();
                } elseif ($_GET['type'] == 4) {
                    include 'models/CalendarStadium.php';
                    $calendarObj = new CalendarStadium();
                }

                $row = $calendarObj->getById($_GET['id']);

                $id = $row['id'];
                $close_date = $row['close_date'];
                $price = $row['price'];
                $paid = $row['paid'];
                $remain = $row['remain'];
                $client_name = $row['client_name'];
                $client_mobile = $row['client_mobile'];
                if ($_GET['type'] == 1) {
                    $close_time = $row['close_time'];
                } elseif ($_GET['type'] == 4) {
                    $from_time = $row['from_time'];
                    $to_time = $row['to_time'];
                }

                ?>
                <div class="card-box table-responsive">
                    <div id="datatable_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                        <div class="row">
                            <table  class="table table-striped table-bordered dataTable no-footer" role="grid" aria-describedby="datatable_info">

                                <tbody>
                                <tr>
                                    <th> <?php echo trans('clientName'); ?> </th>
                                    <td colspan="2"><?php echo $client_name; ?></td>
                                </tr>

                                <tr>
                                    <th> <?php echo trans('clientMobile'); ?></th>
                                    <td colspan="2"><?php echo $client_mobile; ?></td>
                                </tr>
                                <tr>
                                    <th> <?php echo trans('date'); ?> </th>
                                    <td colspan="2"><?php echo $close_date; ?></td>
                                </tr>
                                <?php if ($_GET['type'] == 1) { ?>
                                <tr>
                                    <th> <?php echo trans('time'); ?></th>
                                    <td colspan="2"><?php echo trans($close_time); ?></td>
                                </tr>
                                <?php } elseif ($_GET['type'] == 4) { ?>
                                    <tr>
                                        <th> <?php echo trans('from'); ?></th>
                                        <td colspan="2"><?php echo $from_time; ?></td>
                                    </tr>
                                    <tr>
                                        <th> <?php echo trans('to'); ?></th>
                                        <td colspan="2"><?php echo $to_time; ?></td>
                                    </tr>
                                <?php } ?>
                                <tr>
                                    <th> <?php echo trans('price'); ?></th>
                                    <td colspan="2"><?php echo $price; ?> BD</td>
                                </tr>
                                <tr>
                                    <th> <?php echo trans('paid'); ?> </th>
                                    <td colspan="2"><?php echo $paid; ?> BD</td>
                                </tr>
                                <tr>
                                    <th> <?php echo trans('remain'); ?> </th>
                                    <td colspan="2"><?php echo $remain; ?> BD</td>
                                </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</div>
<?php include("include/footer_text.php"); ?>


<?php include("include/footer.php"); ?>

<script type="text/javascript">
    $("#navigation ul>li").removeClass("active");
    $("#item3").addClass("active");
</script>

<script>

    $('.select2me').select2({
        placeholder: "Select",
        width: 'auto',
        allowClear: true
    });

</script>

</body>
</html>